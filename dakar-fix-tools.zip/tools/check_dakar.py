#!/usr/bin/env python3
"""Validation Dakar — à lancer depuis la racine du dépôt : python3 scripts/check_dakar.py
Vérifie : (1) zéro référence à l'image n°04, (2) les 8 fichiers attendus sont dans assets/dakar/,
(3) aucun fichier dakar-*.webp égaré ailleurs, (4) chaque référence HTML se résout selon la profondeur de la page.
Code de sortie 0 = tout est conforme, 1 = anomalie. Ne modifie rien."""
import os, re, subprocess, sys
EXPECT = [f"dakar-{n:02d}.webp" for n in (1, 2, 3, 5, 6, 7, 8, 9)]
BANNED = "dakar-0" + "4"          # construit ainsi pour que ce fichier ne se contienne pas lui-même
TEXT = (".html", ".htm", ".css", ".js", ".json", ".xml", ".webmanifest", ".md", ".txt", ".yml", ".yaml")
def tracked():
    r = subprocess.run(["git", "ls-files"], capture_output=True, text=True)
    return r.stdout.split("\n") if r.returncode == 0 else [os.path.join(d, f) for d, _, fs in os.walk(".") if ".git" not in d for f in fs]
files = [f for f in tracked() if f and os.path.isfile(f)]
ko = 0
def out(ok, msg):
    global ko; ko += (not ok); print(("[OK] " if ok else "[KO] ") + msg)
hits = []
for f in files:
    if BANNED in f.lower(): hits.append(f"nom de fichier: {f}")
    if f.lower().endswith(TEXT) and os.path.basename(f) != "check_dakar.py":
        for i, l in enumerate(open(f, encoding="utf-8", errors="replace"), 1):
            if BANNED in l.lower(): hits.append(f"{f}:{i}")
out(not hits, f"{len(hits)} référence(s) à l'image n°04 (attendu : 0)" + (" -> " + "; ".join(hits[:8]) if hits else ""))
for n in EXPECT:
    p = "assets/dakar/" + n; ok = os.path.isfile(p)
    if ok:
        b = open(p, "rb").read(12); ok = b[:4] == b"RIFF" and b[8:12] == b"WEBP"
    out(ok, f"{p} {'présent et WebP valide' if ok else 'ABSENT ou invalide'}")
stray = [f for f in files if re.search(r"(^|/)dakar-\d\d\.webp$", f) and not f.startswith("assets/dakar/")]
out(not stray, f"fichiers dakar-*.webp hors assets/dakar/: {stray}")
extra = [f for f in files if f.startswith("assets/dakar/") and os.path.basename(f) not in EXPECT]
out(not extra, f"fichiers inattendus dans assets/dakar/: {extra}")
n_ref = 0
for f in files:
    if not f.lower().endswith((".html", ".htm")): continue
    for ref in re.findall(r"[A-Za-z0-9_./:-]*dakar-\d\d\.webp", open(f, encoding="utf-8", errors="replace").read()):
        n_ref += 1
        SITE = "https://pims5.github.io/cousoum-inc/"
        if ref.startswith(SITE): out(os.path.isfile(ref[len(SITE):]), f"{f}: URL du site {ref[len(SITE):]} existe dans le dépôt"); continue
        if ref.startswith(("http://", "https://", "//")): print(f"[??] {f}: URL externe {ref} (non vérifiable hors ligne)"); continue
        if ref.startswith("/"): out(False, f"{f}: chemin absolu {ref} (casse sous /cousoum-inc/)"); continue
        out(os.path.isfile(os.path.normpath(os.path.join(os.path.dirname(f), ref))), f"{f}: {ref} se résout")
print(f"\n{n_ref} référence(s) HTML contrôlée(s) · anomalies : {ko}")
sys.exit(1 if ko else 0)
