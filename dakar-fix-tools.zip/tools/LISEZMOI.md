# Outils de migration Dakar (branche feat/bilingue-github-pages)

Ces scripts n'ont été testés que sur un dépôt factice, pas sur pims5/cousoum-inc.

1. Depuis un terminal sur le dépôt (Codespaces, Copilot agent, Claude Code…) : `git switch feat/bilingue-github-pages`
2. Copie `check_dakar.py` dans `scripts/` ; lance `python3 fix_dakar.py` (simulation), lis le plan, puis `python3 fix_dakar.py --apply`
3. `python3 scripts/check_dakar.py` doit afficher 0 référence à l'image n°04 et 0 anomalie. Les références hors HTML (CSS/JS) signalées sont à traiter à la main.
4. Contrôle visuel sur un vrai navigateur (téléphone, iPad, ordinateur) ; commit sur la branche ; puis :
   `gh pr create --base main --head feat/bilingue-github-pages --title "fix(dakar): assets/dakar + references" --body "Voir rapport"`
5. Ne fusionne pas avant validation humaine et vérification sur GitHub Pages.
