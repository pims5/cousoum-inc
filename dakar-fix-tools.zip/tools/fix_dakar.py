#!/usr/bin/env python3
"""Migration Dakar — à lancer depuis la racine du dépôt, SUR la branche de travail (jamais main).
  python3 fix_dakar.py            -> simulation (ne change rien)
  python3 fix_dakar.py --apply    -> git mv des 8 fichiers + correction des références HTML selon la profondeur
Ne recrée aucun fichier, ne supprime aucune ressource, n'écrase rien. L'image n°04 n'est jamais créée."""
import os, re, subprocess, sys
BRANCH = "feat/bilingue-github-pages"; APPLY = "--apply" in sys.argv
FILES = [f"dakar-{n:02d}.webp" for n in (1, 2, 3, 5, 6, 7, 8, 9)]; B = "dakar-0" + "4"
def sh(*a): return subprocess.run(a, capture_output=True, text=True)
def die(m): print("ABANDON : " + m); sys.exit(2)
br = sh("git", "rev-parse", "--abbrev-ref", "HEAD").stdout.strip()
if br in ("main", "master"): die("on est sur " + br)
if br != BRANCH: die(f"branche courante '{br}' ≠ '{BRANCH}' (vérifie le nom exact de la branche)")
if sh("git", "status", "--porcelain").stdout.strip(): die("arbre de travail non propre : commit ou stash d'abord")
os.makedirs("assets/dakar", exist_ok=True) if APPLY else None
print(("APPLICATION" if APPLY else "SIMULATION") + f" sur {br}\n== Déplacements ==")
for f in FILES:
    s, d = f, "assets/dakar/" + f
    if os.path.exists(s) and os.path.exists(d): die(f"{s} ET {d} existent : conflit, rien n'est écrasé")
    if os.path.exists(s):
        print(f"git mv {s} {d}")
        if APPLY: r = sh("git", "mv", s, d); r.returncode and die(r.stderr)
    elif os.path.exists(d): print(f"déjà en place : {d}")
    else: print(f"MANQUANT (non inventé) : {f}")
if os.path.exists(B + ".webp") or os.path.exists("assets/dakar/" + B + ".webp"): print("ATTENTION : un fichier de l'image n°04 existe — non touché, à traiter humainement")
print("\n== Références HTML ==")
tok = re.compile(r"([A-Za-z0-9_./:-]*?)(dakar-\d\d\.webp)"); li04 = re.compile(r"<li[^>]*" + B + r"\.webp[^>]*>\s*</li>")
for f in sh("git", "ls-files").stdout.split("\n"):
    if not f.lower().endswith((".html", ".htm")) or not os.path.isfile(f): continue
    src = open(f, encoding="utf-8").read(); depth = len(os.path.dirname(f).split("/")) if os.path.dirname(f) else 0
    pre = "../" * depth + "assets/dakar/"
    new = li04.sub("", src)
    new = tok.sub(lambda m: m.group(0) if m.group(0).startswith(("http://", "https://", "//")) or m.group(2).startswith(B) else pre + m.group(2), new)
    if new != src:
        print(f"{f}: préfixe '{pre}' ({len(tok.findall(src))} réf.)" + (" · entrée n°04 retirée" if li04.search(src) else ""))
        if APPLY: open(f, "w", encoding="utf-8").write(new)
print("\n== Références hors HTML (non modifiées, à décider humainement) ==")
for f in sh("git", "ls-files").stdout.split("\n"):
    if f.lower().endswith((".css", ".js", ".json", ".xml", ".webmanifest")) and os.path.isfile(f):
        for i, l in enumerate(open(f, encoding="utf-8", errors="replace"), 1):
            if "dakar-" in l: print(f"{f}:{i}: {l.strip()[:110]}")
print("\nÉtape suivante : python3 scripts/check_dakar.py" if APPLY else "\nRelance avec --apply pour appliquer.")
